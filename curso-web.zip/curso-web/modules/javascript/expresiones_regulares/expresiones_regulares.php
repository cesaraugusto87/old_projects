<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<script type="text/javascript">
function ValidaCampos(formulario) {

	// Expresiones Regulares
	var er_email = /^(.+\@.+\..+)$/
	var er_id = /\d{7}/
	var er_cadena = /^(?:\+|-)?\D+$/
	var er_telefono= /[0-9]{11}/

	if(!er_email.test(formu.email.value)) {
		alert('Campo E-MAIL no valido')
		return false
	}
	return false
} 
</script>

<body>

<!-- Formulario -->
<form name="formu" action="" onSubmit="return ValidaCampos(this)">
	<p>Email <input type="text" id="email" name="email" value=""></p>
	<p><input type="submit" value="Enviar"></p>
</form>

</body>
</html>
