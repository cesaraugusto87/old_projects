function form_uno(num_form,num_elem_form,color_entrada) {
	document.forms[num_form].elements[num_elem_form].style.backgroundColor=color_entrada;
	document.forms[num_form].elements[num_elem_form].focus();
}

function form_dos(num_form,num_elem_form,color_default) {
	document.forms[num_form].elements[num_elem_form].style.backgroundColor=color_default;
}
