<html>
<head>
	<!-- Metas -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<!-- Título -->
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<!-- Consulta a la Base de Datos -->
<h1>.: Consulta a la Base de Datos</h1>

<?php
	include 'conexion/conectar.php';
	
	// Consulta a la Base de Datos (Tabla Usuarios)
	$query = pg_query("SELECT *
							FROM usuarios
							ORDER BY login");
							
	// Ciclo que recorre el Arreglo del Query
	while($fila = pg_fetch_array($query))
	{
		// Imprime el arreglo
		echo "<pre>";
		print_r($fila);
		echo "</pre>";
	}
?>

</body>
</html>
