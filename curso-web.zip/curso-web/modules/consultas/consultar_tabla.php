<html>
<head>
	<!-- Metas -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<!-- Título -->
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<!-- Consulta a la Base de Datos -->
<h1>.: Consulta a la Base de Datos</h1>

<?php
	include 'conexion/conectar.php';
	
	// Consulta a la Base de Datos (Tabla Usuarios)
	$query = pg_query("SELECT *
							FROM usuarios
							ORDER BY login");
?>							
	
	<!-- Tabla de Usuarios -->
	<table align="center" border="1px">
		<tr bgcolor="#D0DCE0">
			<td>Usuario</td>
			<td>Clave</td>
			<td>Nivel</td>
		</tr>
							
<?php							
	// Ciclo que recorre el Arreglo del Query
	while($fila = pg_fetch_array($query))
	{
?>
		<!-- Imprime los resultados en una tabla -->
		<tr>
			<td><?php echo $fila['login']; ?></td>
			<td><?php echo $fila['passwd']; ?></td>
			<td><?php echo $fila['nivel']; ?></td>
		</tr>
<?php
	}
?>
	</table>
</body>
</html>
