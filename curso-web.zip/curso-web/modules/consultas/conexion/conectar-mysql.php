<?php
	// Nombre del Host
	$host	= "localhost";
	// Nombre de la Base de Datos
	$db		= "curso";
	// Usuario de la Base de Datos
	$user	= "root";
	// Clave de la Base de Datos
	$passwd = "agentes";

	// Abrir la conexión
	$conex=@mysql_connect("$host","$user","$passwd");

	// Chequea la conexión
	if(!$conex){
		echo "Error al Intentar Conectarse con la Base de Datos";
		exit();
	}

	// Verifica la Conexión a la Base de Datos
	if(!@mysql_select_db("$db",$conex)){
		echo "No se pudo conectar correctamente con la Base de datos";
		exit();
	}
?>
