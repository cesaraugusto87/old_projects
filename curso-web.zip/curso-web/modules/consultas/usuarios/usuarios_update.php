<html>
<head>
	<!-- Metas -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<!-- Título -->
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	include ('../conexion/conectar.php');

	// Recibe los datos
	$login				= $_REQUEST['login'];
	$login_original		= $_REQUEST['login_original'];
	$passwd				= $_REQUEST['passwd'];
	$nivel				= $_REQUEST['nivel'];

	// Actualiza los datos del usuario en la Tabla Usuarios
	$query = pg_query("UPDATE usuarios 
							SET
								login	= '$login',
								passwd	= '$passwd',
								nivel	= '$nivel'
							WHERE
								login='$login_original'
						");
						
	// Redirección al archivo principal
	header('Location:usuarios.php');
?>

</body>
</html>
