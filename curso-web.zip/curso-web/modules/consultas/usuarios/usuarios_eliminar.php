<html>
<head>
	<!-- Metas -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<!-- Título -->
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	include ('../conexion/conectar.php');

	// Recibe los Datos
	$login = $_REQUEST['login'];

	// Elimina el usuario de la Tabla usuarios
	$eliminar = pg_query("DELETE
								FROM usuarios
								WHERE login='$login'
							");
							
	// Redirección al archivo principal
	header('Location:usuarios.php');
?>

</body>
</html>
