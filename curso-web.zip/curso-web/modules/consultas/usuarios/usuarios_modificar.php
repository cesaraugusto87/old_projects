<html>
<head>
	<!-- Metas -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<!-- Título -->
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Modificar Usuario</h1>

<!-- Menu de Usuarios -->
<div align="center">
	<a href="usuarios.php">Usuarios</a>
</div>

<form action="usuarios_update.php" method="POST">
<table align="center">
	<tr>
		<td>Nombre del Usuario a modificar</td>
		<td><input type="text" name="login" value="<?php echo $_REQUEST['login']; ?>"></td>
	</tr>
	<tr>
		<td>Clave</td>
		<td><input type="password" name="passwd" value="<?php echo $_REQUEST['passwd']; ?>"></td>
	</tr>
	<tr>
		<td>Nivel</td>
		<td><input type="text" name="nivel" value="<?php echo $_REQUEST['nivel']; ?>"></td>
	</tr>
	<tr>
		<td colspan="2" align="center">
			<input type="submit" name="modificar" value="Modificar Usuario">
			<input type="hidden" name="login_original" value="<?php echo $_REQUEST['login']; ?>" name="modificar">
		</td>
	</tr>
</table>
</form>

</body>
</html>
