<html>
<head>
	<!-- Metas -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<!-- Título -->
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Usuarios</h1>

<form action="usuarios_insertar.php" method="POST">
<table align="center">
	<tr>
		<td>Nombre de Usuario</td>
		<td><input type="text" name="login" value=""></td>
	</tr>
	<tr>
		<td>Clave</td>
		<td><input type="password" name="passwd" value=""></td>
	</tr>
	<tr>
		<td>Nivel</td>
		<td><input type="text" name="nivel" value=""></td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" value="Agregar Usuario" name="agregar"></td>
	</tr>
</table>
</form>

<!-- Consulta a la Base de Datos -->
<h1>.: Listado de Usuarios</h1>

<?php
	include '../conexion/conectar.php';
	
	// Consulta a la Base de Datos (Tabla Usuarios)
	$query = pg_query("SELECT *
							FROM usuarios
							ORDER BY login");
?>							
	
	<!-- Tabla de Usuarios -->
	<table align="center" border="1px">
		<tr bgcolor="#D0DCE0">
			<td>Usuario</td>
			<td>Clave</td>
			<td>Nivel</td>
			<td>Opciones</td>
		</tr>
							
<?php							
	// Ciclo que recorre el Arreglo del Query
	while($fila = pg_fetch_array($query))
	{
?>
		<!-- Imprime los resultados en una tabla -->
		<tr>
			<td><?php echo $fila['login']; ?></td>
			<td><?php echo $fila['passwd']; ?></td>
			<td><?php echo $fila['nivel']; ?></td>
			<td align="center">
				<a onclick="window.location='usuarios_modificar.php?&login=<?php echo $fila['login']; ?>&passwd=<?php echo $fila['passwd']; ?>&nivel=<?php echo $fila['nivel']; ?>'"><img src="../../../images/icon/edit.png"></a>
				<a onclick="window.location='usuarios_eliminar.php?&login=<?php echo $fila['login']; ?>'"><img src="../../../images/icon/delete.png"></a>
			</td>
		</tr>
<?php
	}
?>
	</table>

</body>
</html>
