<html>
<head>
	<!-- Metas -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<!-- Título -->
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	include ('../conexion/conectar.php');

	// Recibe los datos
	$login		= $_REQUEST['login'];
	$passwd		= $_REQUEST['passwd'];
	$nivel		= $_REQUEST['nivel'];

	// Inserta datos en la Tabla Usuarios
	$query = pg_query("INSERT INTO usuarios
							(login,passwd,nivel)
							values ('$login','$passwd','$nivel')
						");
						
	// Redirección al archivo principal
	header('Location:usuarios.php');
?>

</body>
</html>
