<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<!-- Titulo -->
<h1>Mi Primer Formulario</h1>

<form method="GET" action="mis_datos.php">
<table align="center" border="0px">
	<!-- Cuadro de Texto -->
	<tr>
		<td>Nombre</td>
		<td>
			<input type="text" name="nombre" size="50" value="">
		</td>
	</tr>
	<!-- Cuadro de Texto con Barras de Desplazamiento -->
	<tr>
		<td>Observaciones</td>
		<td>
			<textarea cols="50" rows="5" name="observaciones"></textarea>
		</td>
	</tr>
	<!-- Casilla de Verificación -->
	<tr>
		<td>Casilla</td>
		<td><input type="checkbox" name="casilla" value="ON"></td>
	</tr>
	<!-- Botón de Opción -->
	<tr>
		<td>Botón de Opción</td>
		<td>
			<input type="radio" checked name="boton" value="M">
		</td>
	</tr>
	<!-- Menú Desplegable -->
	<tr>
		<td>Menu Desplegable</td>
		<td>
			<select size="1" name="menu">
				<option value="LUNES">Lunes</option>
				<option selected value="MARTES">Martes</option>
				<option value="Miercoles">Miércoles</option>
			</select>
		</td>
	</tr>
	<!-- Campo Oculto -->
	<tr>
		<td>Campo Oculto</td>
		<td><input type="hidden" name="oculto" value="1987"></td>
	</tr>
		<!-- Boton de Comando -->
	<tr>
		<td colspan="2" align="center">
			<input type="submit" name="enviar" value="Enviar">
		</td>
	</tr>
</table>
</form>

</body>
</html>
