<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>.: Curso Desarrollo Web</title></head>
<body>

<?php
	// Verifica si se envió debidamente el formulario
	if(isset($_REQUEST['enviar']))
	{
		// Recibe las Variables
		$nombre			= $_REQUEST['nombre'];
		$observaciones	= $_REQUEST['observaciones'];
		$casilla		= $_REQUEST['casilla'];
		$boton			= $_REQUEST['boton'];
		$menu			= $_REQUEST['menu'];
		$oculto			= $_REQUEST['oculto'];

		echo "<h1>Formulario: Recibe datos del formulario</h1>";
		
		echo "Nombre: $nombre";
		echo "<br/>";
		
		echo "Observaciones: $observaciones";
		echo "<br/>";
		
		echo "Casilla: $casilla";
		echo "<br/>";
		
		echo "Botón $boton";
		echo "<br/>";
		
		echo "Menu: $menu";
		echo "<br/>";
		
		echo "Oculto: $oculto";
	}
	else
	{
		echo "Debe llenar los campos del formulario<br>";
		echo "<a href='formulario.php'>Volver</a>";
	}
?>

</body>
</html>
