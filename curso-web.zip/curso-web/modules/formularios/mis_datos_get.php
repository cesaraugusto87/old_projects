<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Formulario: Recibe datos del formulario</h1>

<?php
	$nombre				= $_GET['nombre'];
	$observaciones		= $_GET['observaciones'];
	$casilla			= $_GET['casilla'];
	$boton				= $_GET['boton'];
	$menu				= $_GET['menu'];
	$oculto				= $_GET['oculto'];
	
	echo "Nombre: $nombre";
	echo "<br>";
	
	echo "Observaciones: $observaciones";
	echo "<br>";
	
	echo "Casilla: $casilla";
	echo "<br/>";
	
	echo "Boton: $boton";
	echo "<br/>";
	
	echo "Menu: $menu";
	echo "<br/>";
	
	echo "Oculto: $oculto";
?>

</body>
</html>
