<html>
<head>
	<title>.: Curso Desarrollo Web </title>
</head>
<body>

<?php

echo "<h1> Estructuras de Control</h1>";

echo "<hr>";
echo "<p>Supongamos dos variables de prueba a=50 b=100</p>";

$a = 50;
$b = 100;

// Sentencia If - Else
echo "<hr>";
echo "<p>.- Sentencia If - Else: (a>b)</p>";

if ($a>$b){
	echo "<p><b>a es mayor que b</b></p>";
}
else {
	echo "<p><b>a no es mayor que b</b></p>";
}

// Sentencia Switch
echo "<hr>";
echo "<p>.- Sentencia Switch: Con valores de a</p>";

Switch ($a){
	case 50:
		echo "<p><b>Entramos en el Caso 01</b></p>";
		break;
	case 30:
		echo "<p><b>Entramos en el Caso 02</b></p>";
		break;
	default:
		echo "<p><b>No fue ninguno de los casos propuestos</b></p>";
}

// Sentencia For
echo "<hr>";
echo "<p>.- Bucle FOR: Nros del 01-10</p>";

// Indice de Control
$i;

for($i=1;$i<=10;$i++){
	echo "$i " ;
}

// Sentencia While
echo "<hr>";
echo "<p>.- Bucle While: Nros del 01-10</p>";

// Indice de Control
$i=1;

while($i <= 10){
	echo "$i ";
	$i++; 
}

// Setencia do while
echo "<hr>";
echo "<p>.- Bucle Do While: Nros del 01-10</p>";

// Indice de Control
$i=1;

do{
	echo "$i ";
	$i++;
}while($i<=10);

?>

</body>
</html>
