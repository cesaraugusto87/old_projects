<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Ejemplo de Include PHP</h1>

<?php
	// Incluye el Pie de Pagina
	include ('pie_pagina.php');
?>

<p>Prueba de continuidad...</p>

</body>
</html>
