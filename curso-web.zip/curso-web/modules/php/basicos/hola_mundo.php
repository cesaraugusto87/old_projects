<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	// Comentario de Linea

	/*
		Comentario
		de
		Bloque
	*/
 
	// echo: Comando para imprimir en pantalla
 	echo "Hola Mundo, yo soy PHP!";
?>

</body>
</html>
