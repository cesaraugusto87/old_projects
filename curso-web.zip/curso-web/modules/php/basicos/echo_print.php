<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	// echo - Muestra una o más cadenas
	echo "<h1>Ejemplos con echo</h1>";

	echo "Hola mundo<br />";
	echo "Hola", "mundo<br />";
	echo "Hola"."mundo<br />";

	// print - Muestra una cadena
	print "<h1>Ejemplos con print</h1>";

	print "Hola mundo"."<br />";
	print "Hola" . "mundo";
?>

</body>
</html>
