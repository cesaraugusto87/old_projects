<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Ejemplo de Require PHP</h1>

<?php
	// Incluye el Pie de Pagina
	require ('pie_pagina.php');
?>

<p>Prueba de continuidad...</p>

</body>
</html>
