<html>
<head>
	<title>.:Curso Desarrollo Web</title>
</head>
<body>

<h1>Constantes</h1>

<?php
	// Constante en PHP
	// Tipos de Constantes: boolean, integer, double, string
	define("CONSTANTE", "Hola Mundo");
	echo(CONSTANTE);
?>

</body>
</html>
