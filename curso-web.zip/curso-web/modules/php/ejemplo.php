<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	// Esto es un Comentario de Línea en PHP
	
	/*
	Esto
	es un Comentario
	de Bloque
	en PHP
	*/
	
	echo "<h1>Ejemplos de PHP</h1>";
	
	// Esto es una Variable
	$variable;
	$VARIABLE;
	
	// Se agrega Valor a una Variable
	$variable	= 5;
	$VARIABLE	= 9;
	$cadena		= 'Hola Mundo';
	$texto		= 'Texto';
	
	// Imprime la Variable
	echo $variable;
	echo $VARIABLE;
	echo $cadena;
	
	// Comillas Complicadas Imprimen el Valor de la Variable
	// Comillas Simples Imprimien de Forma Literal 
	
	echo "<p align='center'>$variable</p>";
	
	// Imprime un Conjunto de Variables
	echo $variable,$VARIABLE,$cadena;
	
	echo "<br />";
	
	// Imprime solo una variable
	print $variable.$VARIABLE.$cadena;
	
	// ^.^
?>
	<p align="center"><?php echo $variable ;?></p>

</body>
</html>
