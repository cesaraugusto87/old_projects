<?php
	class hombre{
		var $nombre;
		var $edad;
		function hombre ($n,$e){		
			$this->nombre=$n;
			$this->edad=$e;		
		}
		function setNombre($n){
			$this->nombre=$n;
		}
		function getNombre(){
			return($this->nombre);		
		}
		function setEdad($e){
			$this->edad=$e;
		}
		function getEdad(){
			return($this->edad);		
		}	
	}
	/*$man= new hombre("Manuel",14);	
	printf ("Nombre: %s", $man->getNombre());
	?><br><?php
	printf ("Edad: %s", $man->getEdad());
	?><br><?php		
	$man->setNombre("Miguel");
	$man->setEdad("22");	
	printf ("Nombre: %s", $man->getNombre());
	?><br><?php
	printf ("Edad: %s", $man->getEdad());
	?><br><?php	*/
?>