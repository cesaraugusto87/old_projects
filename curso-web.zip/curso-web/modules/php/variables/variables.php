<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Variables</h1>

<?php
	// Variables
	// Tipos escalares: boolean, integer, double, string
	// Tipos compuestos: array, object
	// Tipos especiales: resource, NULL

	// Variable en PHP
	$variable1 = "Freak";
	// Variable en PHP
	$variable2 = "Newbie";
	// Variable en PHP
	$variable3 = 15;

	// Imprime variable PHP
	echo "<b>Variable 01:</b> ", $variable1, "<br>";

	// Imprime variable PHP
	ECHO "<b>Variable 02:</b> ", $variable2."<br>";

	// Imprime variable PHP
	echo "<b>Variable 03:</b> ", $variable3, "<br>";
?>

</body>
</html>
