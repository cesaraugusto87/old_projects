<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Settype</h1>

<?php
	// Variable de Prueba
	$variable = "Freak";

	// Imprime variable PHP
	echo "<b>Variable</b> ", $variable, "<br>";

	// settype: Transforma el tipo de variable del modo actual al modo que le introduzcamos
	settype($variable,'integer');
	echo gettype($variable);	
	echo "<br>",$variable;
?>

</body>
</html>
