<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>is_type</h1>

<?php
	// Variable de Prueba
	$variable = "Freak";

	// Imprime variable PHP
	echo "<b>Variable:</b> ", $variable, "<br>";

	// is_type: Las funciones comprueban si una variable es de un tipo dado
	// is_array(), is_bool(), is_float(), is_integer(), is_null(), is_numeric(), is_object(), is_resource(), is_scalar(), is_string()‏
	
	if (is_string($variable))
		echo "Es String";
	else
		echo "No es String";
?>

</body>
</html>
