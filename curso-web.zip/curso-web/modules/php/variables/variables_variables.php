<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Variables Variables</h1>

<?php
	// Variables Variables
	$a = "hola";
	$$a = "mundo";

	echo "$a $hola";
	echo "<br>";
	echo "$a ${$a}";
?>

</body>
</html>
