<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Gettype</h1>

<?php
	// Variable de Prueba
	$variable1 = "Freak";

	// Imprime variable PHP
	echo "<b>Variable:</b> ", $variable1, "<br>";

	// gettype: Obtiene el Tipo de Dato de la Variable
	echo "<br><b>Tipo de Dato de la Variable</b><br>";
	echo gettype($variable1);
?>

</body>
</html>
