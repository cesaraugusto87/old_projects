<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Variables Variables - Idiomas</h1>

<?php
	// Variables Variables - Idiomas
	$mensaje_es="Hola";
	$mensaje_en="Hello";
	$idioma = "es";
	$mensaje = "mensaje_" . $idioma;
	echo $$mensaje;
?>

</body>
</html>
