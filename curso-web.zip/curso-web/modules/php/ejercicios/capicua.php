<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Capicua</h1>

<?php
	// Nro a Verificar
	$num=8596;
	$capicua=0;

	echo "<p>Nro a Probar: $num</p>";

	// Ciclo de Inversion
	while($num!=0){
		$capicua=$capicua*10+$num%10;
		$num=intval($num/10);
	}

	echo "<p>Nro Invertido: $capicua</p>";
?>

</body>
</html>
