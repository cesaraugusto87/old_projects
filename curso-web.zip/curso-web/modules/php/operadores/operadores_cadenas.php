<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	echo "<h1>Operadores de Cadenas de Texto</h1>";

	echo "<p>Supongamos dos cadenas a=Hola y b=''</p>";

	$a = "Hola";
	
	// El Operador punto concatena una variable con otra
	$b = $a . "Mundo";

	echo "<p>$a</p>";
	echo "<p>$b</p>";

	echo "<h2>Uso de las Comillas</h2>";

	// Se le asigna otra valor a la variable
	$a = "Mundo";

	// Esto escribirá 'Hola $a'
	echo "<p>echo con <b>Comillas Simples</b></p>";
	echo 'Hola $a';
	echo "<br>";

	// Esto escribirá "Hola Mundo"
	echo "<p>echo con <b>Comillas Complicadas</b></p>";
	echo "Hola $a";
?>

</body>
</html>
