<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	echo "<h1>Operadores Matematicos</h1>";

	// Variables de Prueba
	$a = 100;
	$b = 50;

	// Ejemplos de Operadores
	echo "<p>Supongamos dos Variables a=",$a,"y b=",$b,"</p>";

	echo "<p>.- Suma de variables: $a + $b = ", $a + $b,"</p>";

	echo "<p>.- Resta de variables: $a - $b = ", $a - $b,"</p>";

	echo "<p>.- Multiplicación de variables: $a * $b = ", $a * $b,"</p>";

	echo "<p>.- Divición de variables: $a / $b = ", $a / $b,"</p>";

	echo "<p>.- Resto de la división entera: $a % $b = ", $a % $b,"</p>";

	echo "<p>.- Suma 1 a la variable a=",$a,"+1 =", ++$a,"</p>";

	echo "<p>.- Resta 1 a la variable a=",$a,"-1 =", --$a,"</p>";
?>

</body>
</html>
