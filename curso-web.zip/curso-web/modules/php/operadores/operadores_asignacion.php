<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	echo "<h2>Operadores de Asignación</h2>";

	// Variables de prueba
	$a = 100;
	$b = 50;

	echo "<p>Supongamos dos variables a=",$a," y b=",$b,"</p>";

	// Operacion $a = $b
	echo "<hr>";
	echo "<p>Valores: a=$a | b=$b</p>";
	echo '$a = $b';
	$a = $b;
	echo "<br>";
	echo "a = $a";

	// Operacion $a += $b;
	echo "<hr>";
	echo "<p>Valores: a=$a | b=$b</p>";
	$a += $b;
	echo '$a += $b';
	echo "<br>";
	echo "a = $a";

	// Operacion $a -= $b
	echo "<hr>";
	echo "<p>Valores: a=$a | b=$b</p>";
	$a -= $b;
	echo '$a -= $b';
	echo "<br>";
	echo "a= $a";

	// Operacion $a *= $b
	echo "<hr>";
	echo "<p>Valores: a=$a | b=$b</p>";
	$a *= $b;
	echo '$a *= $b';
	echo "<br>";
	echo "a= $a";

	// Operacion $a /= $b
	echo "<hr>";
	echo "<p>Valores: a=$a | b=$b</p>";
	$a /= $b;
	echo '$a /= $b';
	echo "<br>";
	echo "a= $a";

	// Operacion $a .= $b
	echo "<hr>";
	echo "<p>Valores: a=$a | b=$b</p>";
	echo '$a .= $b';
	echo "<br>";
	$a .= $b;
	echo "a= $a";
?>

</body>
</html>
