<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Expresiones Regulares</h1>

<?php
	// Cadenas de Prueba
	$cadena1 = "1234567";
	$cadena2 = "abcdefg";
	$cadena3 = "3.14";
	$cadena4 = "1987";
	$cadena5 = "V17525273";

	// Patrones
	$patron = "/^[[:digit:]]+$/";
	$real = "/^(?:\+|-)?\d+\.\d*$/";
	$entero = "/^(?:\+|-)?\d+$/";
	$cedula = "/^[veVE]\d{7}/";

	// Verifica Cadena 01
	if (preg_match($patron, $cadena1))
	{
		echo "<p>La cadena $cadena1 son nros</p>";
	}
	else
	{
		echo "<p>La cadena $cadena1 no son nros</p>";
	}

	// Verifica Cadena 02
	if (preg_match($patron, $cadena2))
	{
		echo "<p>La cadena $cadena2 son nros</p>";
	}
	else
	{
		echo "<p>La cadena $cadena2 no son nros</p>";
	}

	// Verifica Cadena 03
	if (preg_match($real, $cadena3))
	{
		echo "<p>La cadena $cadena3 es un real</p>";
	}
	else
	{
		echo "<p>La cadena $cadena3 no es un real</p>";
	}

	// Verifica Cadena 04
	if (preg_match($entero, $cadena4))
	{
		echo "<p>La cadena $cadena4 es un entero</p>";
	}
	else
	{
		echo "<p>La cadena $cadena4 no es un entero</p>";
	}

	// Verifica Cadena 05
	if (preg_match($cedula, $cadena5))
	{
		echo "<p>La cadena $cadena5 es una cedula</p>";
	}
	else
	{
		echo "<p>La cadena $cadena5 no es una cedula</p>";
	}
?>

</body>
</html>

