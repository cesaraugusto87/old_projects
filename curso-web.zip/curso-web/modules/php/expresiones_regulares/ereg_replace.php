<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>ereg_replace</h1>

<?php
	// Cadena Original
	$cadena="hispano am";
	echo "<b>Cadena Original:</b> $cadena<br>";

	// Cadena a Reemplazar
	$cadena = ereg_replace ("^am",$cadena, "america");

	// Cadena Final
	echo "<b>Cadena Final:</b> $cadena";
?>

</body>
</html>

