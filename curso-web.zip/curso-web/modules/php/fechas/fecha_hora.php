<?php
function horatotal ($horaini,$horafin,$fechaini,$fechafin) {
	// Hora inicial
	$horaini = split(":",$horaini);
	$horini = $horaini[0];
	$minini = $horaini[1];
	
	// Hora final
	$horafin = split(":",$horafin);
	$horfin = $horafin[0];
	$minfin = $horafin[1];
	
	// Fecha inicial
	$fechaini = split('/',$fechaini);
	$diaini = $fechaini[0];
	$mesini = $fechaini[1];
	$anoini = $fechaini[2];
	
	// Fecha final
	$fechafin = split('/',$fechafin);
	$diafin = $fechafin[0];
	$mesfin = $fechafin[1];
	$anofin = $fechafin[2];
	
	// Formato es: Hora, Minuto, Segundo, Mes, Día, Año
	$fecha1 = mktime($horini, $minini, 0, $mesini, $diaini, $anoini); // Inicial
	$fecha2 = mktime($horfin, $minfin, 0, $mesfin, $diafin, $anofin); // Final
	
	$oper = ($fecha2 - $fecha1) / 86403;
	
	// Si el resultado es menor que cero, la fecha con hora inicial es mayor que la final
	if ($oper < '0')
		return "Error en el cálculo, la fecha final es menor que la fecha inicial";
	
	// Resultado de fecha
	$fecha = split("[.]",$oper);
	$dias = $fecha[0];
	// Resultado de hora
	$horas = "0.".$fecha[1];
	settype($horas,"float");	// Formatear la variable a flotante
	$horas = split("[.]",$horas*24);
	// Resultado de minutos
	$minutos = "0.".$horas[1];
	settype($minutos,"float");	// Formatear la variable a flotante
	$minutos = split("[.]",$minutos*60);
	
	return $dias." Dias - ".$horas[0]." Horas ".$minutos[0]." Minutos";
}

$ver = horatotal("23:12","09:04","23/04/2010","25/04/2010");
echo $ver;
?>
