<?php

function ultima_modificacion( $archivos = ''){

	if (empty($archivos)) return false;

	foreach ($archivos as $archivo):
		echo "$archivo : " . date ("d-m-Y", filemtime("$archivo")) . "<br>";
	endforeach;
	
	return true;
}

// Arreglo de Prueba
$archivos=array("carlos.php",
				"calinsoft.php");

// Llamada de la Funcion PHP
ultima_modificacion($archivos);
?>
