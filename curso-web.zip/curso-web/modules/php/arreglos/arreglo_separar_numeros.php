<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	// Nro a Separar
	$num=312752;
	echo "<h1>Separar Nros: $num </h1>";

	// Inicializamos el Arreglo
	$aux[0]=0;
	$aux[1]=0;
	$aux[2]=0;
	$aux[3]=0;
	$aux[4]=0;
	$aux[5]=0;
	$aux[6]=0;

	// Indice del arreglo
	$i=0;
	
	// Ciclo para separar el nro
	while($num!=0){
		// Separa el Numero
		$aux[$i]=$num%10;
		// Corre el Numero
		$num=intval($num/10);
		$i++;
	}

	// Imprime el arreglo final
	echo "<pre>";
	print_r($aux);
	echo "</pre>";
?>

</body>
</html>
