<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Arreglo - Eliminar Espacios</h1>

<?php 
	// Inicializamos el Arreglo
	$array[0]='';
	$array[1]='';
	$array[2]='1';
	$array[3]='2';
	$array[4]='3';
	$array[5]='4';
	$array[6]='5';
	$array[7]='6';
	$array[8]='7';
	
	// Imprime el Arreglo
	echo "<pre>";
	print_r($array);
	echo "</pre>";

	// Recorre el Arreglo y elimina los espacios en blanco
	$i=0;
	for($i=0;$i<count($array);$i++){
		if ($array[$i]==''){
			unset($array[$i]);
			$array=array_values($array);
		}
	}
	
	// Imprime el arreglo
	echo "<pre>";
	print_r($array);
	echo "</pre>";	
?>
</body>
</html>
