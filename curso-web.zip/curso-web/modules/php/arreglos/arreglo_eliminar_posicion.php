<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<?php
	// Ejemplo de Arreglo
	$array = 'ni sus,manos son,tan blancas,ni son,blancas sus,palomas';

	// Separamos el Texto
	$array = explode(',',$array);

	echo "<h1>Arreglo Original</h1>";

	// Imprime el Array
	echo "<pre>";
	print_r($array);
	echo "</pre>";

	// Eliminamos la Posición 04
	unset($array[4]);

	echo "<h1>Arreglo sin la posicion 04</h1>";

	// Imprime el Array
	echo "<pre>";
	print_r($array);
	echo "</pre>";

	// Ajustamos la Posicion del Arreglo
	$array = array_values($array);

	echo "<h1>Arreglo ajustado</h1>";

	// Imprime el Array
	echo "<pre>";
	print_r($array);
	echo "</pre>";
?>

</body>
</html>
