<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Arreglos</h1>

<?php
	// Inicializamos el Arreglo
	$array[0]='';
	$array[1]='';
	$array[2]='1';
	$array[3]='2';
	$array[4]='3';
	$array[5]='4';
	$array[6]='5';
	$array[7]='6';
	$array[8]='7';
	$array[9]='8';

	// Imprime el Arreglo
	echo "<pre>";
	print_r($array);
	echo "</pre>";

	// Recorre e Imprime el Arreglo	
	$i=0;
	for($i=0;$i<count($array);$i++){
		// Imprime el arreglo en la posicion actual
		echo($array[$i]);
		$array=array_values($array);
	}

?>
</body>
</html>
