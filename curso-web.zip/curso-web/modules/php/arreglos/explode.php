<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Explode</h1>

<?php
	// Formato de Fecha
	$fecha = '2006-03-20';
	echo "<p><b>Formato de Fecha:</b> $fecha </p>";

	// Separamos la Fecha en un Arreglo
	$fecha_explode = explode("-", $fecha);

	/*
		.- Separa la variable fecha en tres partes
		
		Año		$fecha_explode[0]
		Mes		$fecha_explode[1]
		Dia		$fecha_explode[2]
	*/
	
	// Formato Separado
	echo "<b>Dia:</b> $fecha_explode[2] <br>";
	echo "<b>Mes:</b> $fecha_explode[1] <br>";
	echo "<b>A#o:</b> $fecha_explode[0] <br>";
?>

</body>
</html>
