<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Funciones - Paso de parametros por valor</h1>

<?php

	// Funcion en PHP: Parametros por valor
	function suma($x, $y)
	{
		$s = $x + $y;
		return $s;
	}

	// Valores de Prueba
	$a=4;
	$b=15;

	// Llamada de la funcion
	$c=suma($a, $b);

	echo "<h2>Funcion Suma</h2>";
	echo "<p><b>Valores:</b> a=$a | b=$b</p>";
	echo "<p><b>Resultado =</b> $c</p>";
?>

</body>
</html>
