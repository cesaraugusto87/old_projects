<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Argumentos por Defecto</h1>

<?php
	// Funcion en PHP: Argumentos por defecto
	function muestranombre($titulo = "Sr.")
	{
		echo "Estimado $titulo: ";
	}

	muestranombre();
	echo "<br>";
	muestranombre("Prof.");
?>

</body>
</html>
