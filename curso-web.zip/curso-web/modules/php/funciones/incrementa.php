<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Funcion - Paso de parametros por referencia</h1>

<?php

	// Funcion en PHP: Parametros por referencia
	function incrementa(&$a)
	{
	   $a = $a + 1;
	}

	// Valor de Prueba
	$a=1;

	echo "<h2>Funcion Incrementa</h2>";
	echo "<p><b>Incrementa el valor de: </b> a=$a</p>";

	// Llamada de la Funcion
	incrementa($a);

	echo "<p><b>Resultado:</b> $a</p>"
?>

</body>
</html>
