<html>
<head>
	<title>.: Curso Desarrollo Web</title>
</head>
<body>

<h1>Argumentos por Valor y por Defecto</h1>

<?php
	function muestranombre ($nombre, $titulo= "Sr.")
	{
		echo "Estimado $titulo $nombre:";
	}

	muestranombre ("Fernandez");
	echo "<br>";
	muestranombre ("Fernandez", "Prof.");
?>

</body>
</html>
