#!/bin/bash

## Colores
YELLOW="\033[1;33m"
RED="\033[0;31m"
ENDCOLOR="\033[0m"

echo "Script de Instalación de Servidor Web..."

## Verifica si el usuario es el Usuario Administrador
if [ $USER != root ]; then
  echo -e "$RED Error: debes ser root"
  echo -e "$YELLOW Saliendo... $ENDCOLOR"
  exit 0
fi

# ---------------------------------------------------------
# - Inicio de la Configuración
# ---------------------------------------------------------

echo -e "$YELLOW Actualizando listado de repositorios... $ENDCOLOR"

# Actualizando el listado de los repositorios
apt-get update

# ---------------------------------------------------------
# - Desarrollo
# ---------------------------------------------------------

echo -e "$YELLOW Paquetes de Desarrollo... $ENDCOLOR"

## Compiladores
apt-get install -y gcc g++

## Paquetes de Compilación
apt-get install -y build-essential libxml2-dev

## Editores de Texto
apt-get install -y geany

## Servidor Web
apt-get install -y apache2

## PHP
apt-get install -y php5 php5-gd php5-cli php5-curl

## MySQL
apt-get install -y mysql-server

## Gestor de MySQL Server
apt-get install -y phpmyadmin

## PostgreSQL
apt-get install -y postgresql-8.4

## Gestor de PostgreSQL
apt-get install -y pgadmin3

## ---------------------------------------------------------
## - Librerias de Conexion
## ---------------------------------------------------------

echo -e "$YELLOW Librerias de Conexion... $ENDCOLOR"

## Apache / MySQL
apt-get install -y libapache2-mod-auth-mysql

## Apache / PostgreSQL
apt-get install -y libapache2-mod-auth-pgsql

## PHP / MySQL
apt-get install -y php5-mysql

## PHP / PostgreSQL
apt-get install -y php5-pgsql

## ---------------------------------------------------------
## - Reinicio de Servicios
## ---------------------------------------------------------

echo -e "$YELLOW Reinicio de Servicios... $ENDCOLOR"

## Configuracion del apache2.conf
## echo "Include /etc/phpmyadmin/apache.conf" | sudo tee -a /etc/apache2/apache2.conf

## MySQL
/etc/init.d/mysql restart

## PostgreSQL
/etc/init.d/postgresql-8.4 restart

## Apache
/etc/init.d/apache2 restart

## ---------------------------------------------------------
## - Fin del Script
## ---------------------------------------------------------

echo -e "$YELLOW Fin del Script... $ENDCOLOR"
